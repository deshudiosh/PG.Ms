''' 
    Demonstrates outputting text the MAXScript listener. 
''' 

import MaxPlus
MaxPlus.Core.WriteLine("hello world")