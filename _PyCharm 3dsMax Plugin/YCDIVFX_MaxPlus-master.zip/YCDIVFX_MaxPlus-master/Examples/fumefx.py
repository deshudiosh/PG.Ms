import maxfumefx.jobsim as js


ffxsim = js.FumeFxJobSim()

ffxsim.simtodeadline()
